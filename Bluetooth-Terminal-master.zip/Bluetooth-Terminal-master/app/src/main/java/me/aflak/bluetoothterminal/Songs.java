package me.aflak.bluetoothterminal;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;

public class Songs extends AppCompatActivity {

    WebView v1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_songs);
        v1=(WebView)findViewById(R.id.w1);
        v1.getSettings().setLoadsImagesAutomatically(true);
        v1.loadUrl("https://www.saavn.com/s/album/tamil/Melody-Hits-Of-Ilayaraja-Melody-Instrumental-Tamil-2007/bZW8c7P7zco_");
    }
    public void stress(View view)
    {
        Intent i=new Intent(this,Select.class);
        startActivity(i);
    }
}
